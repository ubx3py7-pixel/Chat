
import express from "express";
import http from "http";
import fs from "fs";
import multer from "multer";
import dotenv from "dotenv";
import { Server } from "socket.io";
import { logText, logMedia } from "./tgLogger.js";

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));

let users = JSON.parse(fs.readFileSync("users.json"));

/* ---------- LOGIN ---------- */
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (users[username] && users[username].password === password) {
    res.json({ ok: true, role: users[username].role });
  } else {
    res.json({ ok: false });
  }
});

/* ---------- ADMIN CREATE USER ---------- */
app.post("/admin/create", (req, res) => {
  const { adminUser, adminPass, username, password } = req.body;

  if (adminUser !== "admin" || adminPass !== "admin") {
    return res.status(403).send("Unauthorized");
  }

  users[username] = { password, role: "user" };
  fs.writeFileSync("users.json", JSON.stringify(users, null, 2));
  res.send("User created");
});

/* ---------- FILE UPLOAD ---------- */
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, file.mimetype.startsWith("audio") ? "uploads/voice" : "uploads/stickers");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});
const upload = multer({ storage });

app.post("/upload", upload.single("file"), (req, res) => {
  res.json({ path: req.file.path.replace("\\", "/") });
});

/* ---------- SOCKET CHAT ---------- */
io.on("connection", (socket) => {
  socket.on("join", ({ username, room }) => {
    socket.username = username;
    socket.room = room;
    socket.join(room);
  });

  socket.on("message", async (text) => {
    io.to(socket.room).emit("message", {
      user: socket.username,
      text
    });

    await logText(`💬 <b>${socket.username}</b>\nRoom: ${socket.room}\n${text}`);
  });

  socket.on("media", async ({ url, type }) => {
    io.to(socket.room).emit("media", {
      user: socket.username,
      url,
      type
    });

    await logText(`📎 <b>${socket.username}</b>\nRoom: ${socket.room}`);
    await logMedia(type, `http://localhost:3000/${url}`);
  });
});

server.listen(3000, () => {
  console.log("✅ Server running on http://localhost:3000");
});