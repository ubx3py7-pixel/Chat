const socket = io();
const room = prompt("Room name?");
const user = prompt("Username?");

socket.emit("join", { username: user, room });

function send() {
  socket.emit("message", msg.value);
  msg.value = "";
}

function sendFile() {
  const f = file.files[0];
  const fd = new FormData();
  fd.append("file", f);

  fetch("/upload", { method: "POST", body: fd })
    .then(r => r.json())
    .then(d => socket.emit("media", {
      url: d.path,
      type: f.type.startsWith("audio") ? "audio" : "image"
    }));
}

let rec, chunks = [];

async function start() {
  const s = await navigator.mediaDevices.getUserMedia({ audio: true });
  rec = new MediaRecorder(s);
  rec.start();
  rec.ondataavailable = e => chunks.push(e.data);
}

function stop() {
  rec.stop();
  rec.onstop = () => {
    const b = new Blob(chunks, { type: "audio/webm" });
    chunks = [];
    const fd = new FormData();
    fd.append("file", b);
    fetch("/upload", { method: "POST", body: fd })
      .then(r => r.json())
      .then(d => socket.emit("media", { url: d.path, type: "audio" }));
  };
}

socket.on("message", d => {
  messages.innerHTML += `<p><b>${d.user}:</b> ${d.text}</p>`;
});

socket.on("media", d => {
  messages.innerHTML += d.type === "image"
    ? `<img src="/${d.url}" width="120">`
    : `<audio controls src="/${d.url}"></audio>`;
});